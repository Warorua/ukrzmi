<div style="margin-bottom:35px" class="row">
    <b class="fs-6 text-muted">Comments (0)</b>




    <div class="col-md-12">
  <ul class="nav" id="myTab" role="tablist">
  <li class="nav-item" role="presentation">
    <a class="nav-link active text-dark fw-bold" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="link" role="tab" aria-controls="home" aria-selected="true">All</a>
  </li>
  <li class="nav-item" role="presentation">
    <a class="nav-link text-dark" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="link" role="tab" aria-controls="profile" aria-selected="false">Experts</a>
  </li>
  <li class="nav-item" role="presentation">
    <a class="nav-link text-dark" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="link" role="tab" aria-controls="contact" aria-selected="false">Members</a>
  </li>
</ul>
<div class="tab-content mt-3" id="myTabContent">
  <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
<div class="w-100 border border-2 border-secondary">
    <div class="p-3">
        <div class="col-md-10">
        <img src="http://www.venmond.com/demo/vendroid/img/avatar/big.jpg" width="40px" class="" alt="...">
        <tx>Roberta - <b>Blogger</b></tx>
        </div>
    
        <textarea style="width:98%; height:100px; border:none; border-radius:15px; margin:auto; margin-top:20px">Express yourself here.</textarea>
        <div class="d-flex justify-content-end">
          <button class="btn btn-secondary btn-sm">Post</button>
        </div>
    </div>
</div>
<div class="d-flex justify-content-center mt-3">
          <button class="btn btn-outline-dark w-75">Read all comments</button>
</div>

  </div>
  <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">...</div>
  <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
</div>  
</div>


</div>
<?php
include 'home/block_article.php';
?>