<!------
<style>
     /* ///Medium devices (desktops, 992px and up)///////////////////////////// */
 @media (max-width: 768px){ 
    /* Hide scrollbar for Chrome, Safari and Opera */
.example::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
.example {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
} 
  .newsCard{
    width: 52%;
    float: left!important;
    position: relative !important;
    padding-left: 0px;
    padding-right: 0px;
    margin-left: 0px;
  }
  .cardColumn_2 {
      display: none;
  }
  .cardColumn .col-md-3{
      width: 50%;
      padding-left: 12px;
  }

  .cardColumn {
      padding: auto;
      width: 100%;
      overflow-x: hidden;
      justify-content: center;
      margin-right: 0px;
  }
  .catColumn {
padding: auto;
width: 100%;
overflow-x: hidden;
justify-content: center;
}

  .cardColumn .card-content {
     position: relative;
  }
  .cardPhoto{
      width: 100%!important;
      
  }
  .imgTitle{
      width:100%!important;
  }
  .imgFrame{
    width:100%!important;
  }
  .card>.card-content {
        padding-left: 0px;
        height: 220px;
        width: 92%;
        border: none;
        float: left;
        position: relative !important;
    }
    .cardHead {

width: 100%;
margin: 0px auto;
font-weight: 600;
font-size: 15px;
line-height: 18px;
color: #000000;
height: 35px;
overflow-y: hidden;
}

.cardFoot {
        position: absolute;
        margin-top: 10px;
    }

    .ellipBox {
        float: right;
        width: 5px;
       margin-right: 3px;
       padding-left: 6px;
    }

    .cardEllip {
        width: 5px;
        height: 5px;
        background: #C4C4C4;
        border-radius: 50%;
        margin-top: 7px;
    }

    .cardCat {
        font-style: normal;
        font-weight: normal;
        font-size: 11px;
        color: #8A8686;
        overflow-x: hidden;
        white-space: nowrap;
        
    }

    .cardTime {
        float: right;     
        margin-right: 8px;
  padding-left: 8px;
  font-size: 11px;
    }

    .cardCategory {   
      float: left;   
        padding-right: 0px!important;
    }
  .cardLink{
    text-decoration:none;
  }
  .cardLink:hover{
    text-decoration:none;
    color:#0057b7!important;
  }
  .newsContainer {
  margin-left: 0px;
  width: 100%!important;
    }
.topRow{ 
display: none;
}


    .homeContent{
  width: 100%;
}
.newsHead {
        font-style: normal;
        font-weight: 500;
        font-size: 22px;
        line-height: 26px;
        margin-left: 15px;
        color: #000000;
    }
.cardBlock {
        width: 105%;   
        padding-left: 0px;
        padding-right: 0px;
        margin-left: 5px;
        align-items: center;
        justify-content: center;
        display: block;
    }
.cardBlock .row{
  width: 106%;       
 padding-left: -5px;
 margin-left: -12px;
 margin-right: 10px;
 justify-content: center;
 display: flex;
 align-items: center;
    }
#myTabContent .row{
    width: 100%;
    padding-left: 5px;
    padding-right: 0px;
}
#myTabContent .row .row{
    width: 100%;
    padding-left: 0px;
    padding-right: 0px;
}
.imgTitle .blogTitle {
        margin: 0;
        text-align: left;
        letter-spacing: 2px;
        color: #252525;
        position: absolute;
        background-color: rgba(255, 255, 255, 0.7);
        
        height: 24px;
        top: 0;
        font-weight: normal;
        padding: 0 10px 2px 6px;
        font-family: Roboto;
    }
  .tagBody{
    margin-left: -5px;
  }
    }
</style> ------------>