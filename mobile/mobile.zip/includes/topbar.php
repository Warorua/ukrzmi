
<div class="topBlockA">
  
<div class="d-flex justify-content-between">
    
<div class="d-flex justify-content-start">

<div class="position-relative">
<div style="width: 30px; height:30px;" class="position-absolute bg-light mt-1 ms-1"></div>
 <img style="z-index: 10" src="images/logo.png" class="position-absolute" width="45px" height="45px"/> 
</div>


<p style="z-index: 20" class="text-light topLogoText ms-5">Ukrzmi</p>
</div>
    


<div class="d-flex justify-content-end">
<ul class="nav topNav">
  <li class="nav-item">
    <a class="nav-link text-light" href="#"><i class="fa-solid fa-user"></i></a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-light" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBothOptions" aria-controls="offcanvasWithBothOptions"><i class="fa-solid fa-bars"></i></a>
  </li>
</ul>
</div>

</div>

</div>



<div class="col-sm-12 tobBlockB">
    
</div>
<?php
include 'includes/menu.php';
?>