<div class="w-100 d-flex justify-content-center mt-2 p-2">

<div class="w-100 bg-primary">
<div class="">

 <div class="col-md-4 m-2 d-flex justify-content-between">
<h6 class="text-center text-white pt-2 w-50">Subscribe to our newsletter.</h6>    
<div class="w-50 p-1 text-center bg-warning">
    <b class="mt-4 fs-6">"Very good brief"</b><br/>
   <small class="text-muted">Ukrzmi news aggregator</small>
</div>
</div>  

<div class="col-md-7 p-2">
<div class="d-flex justify-content-between mt-2">
<div class="input-group input-group-sm w-75">
<input class="form-control" type="text" placeholder="Subscribe now" />
</div>
<button class="btn btn-warning btn-sm" type="submit">Subscribe</button>
</div>
</div>

</div>
</div>
</div>