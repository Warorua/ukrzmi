<footer style="background: #0057b7;" class="w-100 p-2">
<div class="d-flex justify-content-between">
<div class="w-25">

<div class="position-relative">
<div style="width: 40px; height:40px; top:10;" class="position-absolute bg-light mt-1 ms-1"></div>
 <img style="z-index: 10" src="images/logo.png" class="position-absolute" width="55px" height="55px"/> 
</div>

</div>
<div class="">
<p class="text-center text-white fs-6">Privacy Policy - Terms & Conditions</p>
<p class="text-center text-white fs-6">Advertising - Support Center</p>
</div>
</div>
</footer>