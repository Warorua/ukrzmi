<div class="catImgRow">
<div class="w-100">
<img class="articleImage" src="https://www.ukrzmi.com/images/<?php echo $data['photo'] ?>" class="img-fluid" alt="...">
</div>


</div>