<div class="row">
<?php
include 'full_coverage/grid.php';
?>
<hr/>
 <?php
include 'full_coverage/list.php';
?>
</div>