<?php
$html = '
<div>
<img alt="Психолог радить не забувати про маленькі радощі навіть під час війни / фото  (Сергій Чузавков / Олександр Синиця)" data-height="810" data-width="1200" src="https://images.unian.net/photos/2022_04/1649833812-2888.jpg?0.2052923586308919" title="Психолог радить не забувати про маленькі радощі навіть під час війни / фото  (Сергій Чузавков / Олександр Синиця)"/>
<img src="https://images.unian.net/photos/2022_04/1649833812-2888.jpg?0.2052923586308919" title=""/>
<div></div>
<p>Психолог радить не забувати про маленькі радощі навіть під час війни</p>
</div>

';
$first = strstr($html, '<div>');
$second = strstr($first, '</div>');
$final = str_replace($second, "", $first);
echo $final;
?>