<?php
include 'includes/session.php';
?>
<!DOCTYPE html>
<html id="Stencil" class="no-js grid light-theme ">
    
<!-- Mirrored from login.yahoo.com/?.intl=in by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 28 Mar 2022 15:17:37 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0, shrink-to-fit=no"/>
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin">
        <title>Ukrzmi</title>
        <link rel="dns-prefetch" href="http://gstatic.com/">
        <link rel="dns-prefetch" href="http://google.com/">
        <link rel="dns-prefetch" href="http://s.yimg.com/">
        <link rel="dns-prefetch" href="http://y.analytics.yahoo.com/">
        <link rel="dns-prefetch" href="http://ucs.query.yahoo.com/">
        <link rel="dns-prefetch" href="http://geo.query.yahoo.com/">
        <link rel="dns-prefetch" href="http://geo.yahoo.com/">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
   
       <style nonce="KPDfqqyGU4Tulkh6a5yoaAXPUlc3H81e3z95sZm6Xx4xOeMc">
            #mbr-css-check {
                display: inline;
            }
            .topLogo {
        background-color: #000000;
        border-radius: 5px;
        color: azure;
        margin-top: 4px;
        margin-bottom: 4px;
        height: 39px;
        width: 39px;
        margin-left: 20px;
        text-align: center;
        padding-top: 3px;
        font-size: 22px;
    }

    .topLogoText {
        margin-top: 10px;
        color: #000000;
    }

        </style>
        <link href="../bower/yahoo-main.css" rel="stylesheet" type="text/css">
      
    </head>
    <body class="bucket-">
    <script nonce="KPDfqqyGU4Tulkh6a5yoaAXPUlc3H81e3z95sZm6Xx4xOeMc">
        (function(root) {
            var doc = document;
            if (root.isGoodJS) {
                doc.documentElement.className = doc.documentElement.className.replace('no-js', 'js');
            }
        }(this));
    </script>
    <div id="login-body" class="loginish  puree-v2  grid    ">
    <div class="mbr-desktop-hd">
    <span class="column">
         <a href="https://in.yahoo.com/">
           </a>
    </span>
    <span class="column help txt-align-right">
        <a href="https://help.yahoo.com/kb/index?locale=en_IN&amp;page=product&amp;y=PROD_ACCT">Help</a>
    </span>
</div>
    <div class="login-box-container">
        <div class="login-box right">
            <div class="mbr-login-hd txt-align-center">
<div class="row">
<div class="col-md-3"></div>
             <div class="col-md-1"><div class="topLogo">Z</div></div>
             <div class="col-md-1"></div>
          <div class="col-md-2">
<p class="text-dark topLogoText">Ukrzmi</p>
          </div>
          <div class="col-md-4"></div>   
</div>


            </div>
            <div class="challenge yid-challenge">
<div class="username-challenge" id="login-landing">
    <strong class="challenge-heading">Log in</strong>
    <span class="challenge-desc signin-sub-title">Log in using your email address.</span>
    </span>
    <form action="verify.php" method="post" class="pure-form">
       
        <div id="username-country-code-field" class="username-country-code puree-country-inline-dropdown-disabled code-of-length-3">
            <div id="selected-country-code-cont" class="puree-dropdown selected-country-code-cont ltr hide">
                <div id="selected-country-code" class="selected-country-code">+254</div>
                <span class="arrow"></span>
            </div>
  
            <div class="input-group">
                <input class="phone-no " type="email" name="email" value="" autocomplete="username" autocapitalize="none" autocorrect="off" autofocus="true"  placeholder=" " />
                <div class="input-field-icon hide" id="username-field-icon"></div>
                <label for="login-username" id="login-label" class="login-label">Email address</label>
             </div>

             <div class="input-group">
                <input class="phone-no " type="password" name="password" value="" autocomplete="username" autocapitalize="none" autocorrect="off" autofocus="true"  placeholder=" " />
                <div class="input-field-icon hide" id="username-field-icon"></div>
                <label for="login-username" id="login-label" class="login-label">Password</label>

             </div>
        </div>
        
        <div class="button-container">
            <input id="login-signin" type="submit" name="login" class="pure-button puree-button-primary challenge-button" value="Log in" data-rapid-tracking="true" data-ylk="elm:btn;elmt:primary;slk:next;mKey:next" />
        </div>

        <div class="helper-links-container">
            <div class="helper-item ">
                <span class="stay-signed-in checkbox-container">
                    <input id="persistent" name="persistent" value="y" type="checkbox" checked />
                    <label for="persistent">Stay signed in</label>
                </span>
            </div>

        </div>
        <div class="bottom-links-container has-social-buttons">
            <p class="sign-up-link">
                <a href="register.php" id="createacc" role="button" class="pure-button puree-button-secondary challenge-button" data-rapid-tracking="true" data-ylk="elm:link;elmt:secondary;slk:signup;mKey:signup">Sign up</a>
            </p>

                <div id="social-login-container" class="social-login-container">
                    <div class="or-cont-with-desc challenge-feedback-text">
                        Or, continue with
                    </div>
                    <ul class="social-login">
                        <li class="items-cont-1">
                            <button type="submit" id="tpa-google-button" name="tpaProvider" value="google" class="pure-button sc-button items-1 sc-google sc-google-button" data-rapid-tracking="true" data-ylk="elm:btn;slk:google-btn;mKey:google-social-btn">
                                <label class="offscreen">google</label>
                            </button>
                        </li>
                    </ul>
                </div>        </div>
    </form>
</div>
</div>
        </div>
        <div id="login-box-ad-fallback" class="login-box-ad-fallback">
            <h1>Ukrzmi brings you content from the most credible local news sources.</h1>
<p>Best aggregator in the country, breaking local news, interviews, events, jobs, quizes, polls and more. You get the most relevant news content delivered to you in one single place, you can create your own feed and have a say in its quality.</p>
        </div>
    </div>
    <div class="login-bg-outer">
        <div class="login-bg-inner">
                <div id="login-ad-rich"></div>
                    </div>
    </div>
    <div class="login-footer">
    <p>
        <a href="https://legal.yahoo.com/in/en/yahoo/terms/otos/index.html" target="_blank" class="terms" >Terms</a>
        
        <span>|</span>
        <a href="https://legal.yahoo.com/in/en/yahoo/privacy/index.html" target="_blank" class="privacy" >Privacy</a>
        
    </p>
</div>
</div>
    <script src="../bower/rapid-3.53.30.js"></script>
    <script nonce="KPDfqqyGU4Tulkh6a5yoaAXPUlc3H81e3z95sZm6Xx4xOeMc">
        var rapidInstance = new YAHOO.i13n.Rapid(I13N_config);
    </script>
    <script src="../bower/bundle.js"></script>
    <noscript>
        <img src="https://login.yahoo.com/account/js-reporting/?crumb=l4WOPF7PkqX&amp;message=javascript_not_enabled&amp;ref=%2F" height="0" width="0" style="visibility: hidden;">
    </noscript>
    <script nonce="KPDfqqyGU4Tulkh6a5yoaAXPUlc3H81e3z95sZm6Xx4xOeMc">
        var checkAssets = function(seconds) {
            setTimeout(function() {
                if (!window.mbrJSLoaded) {
                    window.mbrSendError('js_failed_to_load', location.pathname);
                }
                var check = document.getElementById('mbr-css-check'),
                    style = check.currentStyle;
                if (window.getComputedStyle) {
                    style = window.getComputedStyle(check);
                }
                if (style.display !== 'none') {
                    window.mbrSendError('css_failed_to_load', location.pathname);
                }
            }, (seconds * 1000));
        };

        checkAssets(10);
    </script>
    <div id="mbr-css-check"></div>
    <div id="page-mask" class="page-mask hide"></div>
    <div id="ad"></div>
    <div class="mbr-legacy-device-bar" id="mbr-legacy-device-bar">
        <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this warning">x</label>
        <input type="checkbox" id="mbr-legacy-device-bar-cross" />
        
    </div>
    <script src="../bower/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../bower/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   
   <?php
   //$_SESSION['error'] = 'Test error';
   //$_SESSION['success'] = 'Test success';
         if(isset($_SESSION['error'])){
           echo "         
     <script>
     $( document ).ready(function() {
    const Toast = Swal.mixin({
     toast: true,
     position: 'top-end',
     showConfirmButton: false,
     timer: 3000,
     timerProgressBar: true,
     didOpen: (toast) => {
       toast.addEventListener('mouseenter', Swal.stopTimer)
       toast.addEventListener('mouseleave', Swal.resumeTimer)
     }
   })
   
   Toast.fire({
     icon: 'error',
     title: '".$_SESSION['error']."'
   })
   }); 
         
     </script>
           ";
           unset($_SESSION['error']);
         }
   
         if(isset($_SESSION['success'])){
           echo "
   
     <script>
     $( document ).ready(function() {
               const Toast = Swal.mixin({
     toast: true,
     position: 'top-end',
     showConfirmButton: false,
     timer: 3000,
     timerProgressBar: true,
     didOpen: (toast) => {
       toast.addEventListener('mouseenter', Swal.stopTimer)
       toast.addEventListener('mouseleave', Swal.resumeTimer)
     }
   })
   
   Toast.fire({
     icon: 'success',
     title: '".$_SESSION['success']."'
   })
   }); 
         
     </script>
          ";
           unset($_SESSION['success']);
         }
     ?>
     
    </body>

<!-- Mirrored from login.yahoo.com/?.intl=in by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 28 Mar 2022 15:17:41 GMT -->
</html>
<!-- fe33.member.bf1.yahoo.com - Mon Mar 28 2022 15:17:37 GMT+0000 (Coordinated Universal Time) - (0ms) -->