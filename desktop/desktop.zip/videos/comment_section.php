<div style="margin-bottom:35px" class="row">
    <b class="fs-4">Comments (0)</b>




    <div class="col-md-12 mt-4">
  <ul class="nav" id="myTab" role="tablist">
  <li class="nav-item" role="presentation">
    <a class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="link" role="tab" aria-controls="home" aria-selected="true">All</a>
  </li>
  <li class="nav-item" role="presentation">
    <a class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="link" role="tab" aria-controls="profile" aria-selected="false">Experts</a>
  </li>
  <li class="nav-item" role="presentation">
    <a class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="link" role="tab" aria-controls="contact" aria-selected="false">Members</a>
  </li>
</ul>
<div class="tab-content mt-3" id="myTabContent">
  <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
<div class="w-100 border border-3 border-secondary">
    <div class="row p-3">
        <div class="col-md-10">
        <img src="http://www.venmond.com/demo/vendroid/img/avatar/big.jpg" width="40px" class="" alt="...">
        <tx>Roberta - <b>Blogger</b></tx>
        </div>
        <div class="col-md-2 justify-content-end"><button class="btn btn-light" type="button">Post</button></div>

        <textarea style="width:98%; height:100px; border:solid 3px grey; border-radius:15px; margin:auto; margin-top:20px">Express yourself here.</textarea>
    </div>
</div>
  

  </div>
  <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">...</div>
  <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
</div>  
</div>










</div>