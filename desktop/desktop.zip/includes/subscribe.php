<div class="w-100 d-flex justify-content-center p-2">
<div class="w-100 bg-primary ps-4">
<div class="row">
<div class="col-md-7 p-2">
<h4 class="text-white pb-3">Subscribe to our newsletter.</h4>
<div class="d-flex justify-content-between mt-4">
<div class="input-group input-group-sm w-75">
<input class="form-control" type="text" placeholder="Subscribe now" />
</div>
<button class="btn btn-warning btn-sm" type="submit">Subscribe</button>
</div>
</div>

<div class="col-md-4 ms-2">
<div class="topBlockA_2 w-75 p-4">
    <b class="text-center mt-4 fs-6">"Very good brief"</b>
            <small class="topBlockA_1_text text-muted">Ukrzmi news aggregator</small>
</div>
</div>


</div>
</div>
</div>