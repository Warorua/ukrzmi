﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","ku",{title:"هەڵگری ڕەنگ بۆ ڕووکاری بەکارهێنەر",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"کۆمەڵە ڕەنگە دیاریکراوەکانی پێشوو",config:"ئەم دەقانە بلکێنە بە پەڕگەی config.js-fil"});