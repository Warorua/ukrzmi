﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","cy",{title:"Dewisydd Lliwiau'r UI",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Setiau lliw wedi'u cyn-ddiffinio",config:"Gludwch y llinyn hwn i'ch ffeil config.js"});